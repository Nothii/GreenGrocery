package com.example.Greengrocery_3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Greengrocery3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
