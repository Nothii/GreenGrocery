package com.example.Greengrocery_3.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Cart")
public class cart {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CartId")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "CustomerId", referencedColumnName = "LoginId",nullable = true)
	private Login customer;

    @ManyToOne
	@JoinColumn(name = "ProductId", referencedColumnName = "ProductId")
	private product2 product;

	private int quantity;
	private double price;

	    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Login getCustomer() {
        return customer;
    }

    public void setCustomer(Login customer) {
        this.customer = customer;
    }

    public product2 getProduct() {
        return product;
    }

    public void setProduct(product2 product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
	
	
}
