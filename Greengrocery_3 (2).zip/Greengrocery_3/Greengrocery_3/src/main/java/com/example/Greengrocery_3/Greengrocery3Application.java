package com.example.Greengrocery_3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Greengrocery3Application {

	public static void main(String[] args) {
		SpringApplication.run(Greengrocery3Application.class, args);
	}

}
