package com.example.Greengrocery_3.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.Login;
import com.example.Greengrocery_3.Entity.Order;
import com.example.Greengrocery_3.Entity.cart;
import com.example.Greengrocery_3.Entity.cart2;



public interface Order_repo extends JpaRepository<Order, Integer> {
}