package com.example.Greengrocery_3.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.Greengrocery_3.Entity.Order;
import com.example.Greengrocery_3.service.CartService;
import com.example.Greengrocery_3.service.OrderService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public ResponseEntity<Order> createOrder(@RequestParam Integer cartId) {
        Order order = orderService.createOrderFromCart(cartId);
        return ResponseEntity.ok(order);
    }
}

