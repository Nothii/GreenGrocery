package com.example.Greengrocery_3.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.product2;
import com.example.Greengrocery_3.Entity.product3;




public interface Product_repo2 extends JpaRepository<product3, Integer> {
	
}