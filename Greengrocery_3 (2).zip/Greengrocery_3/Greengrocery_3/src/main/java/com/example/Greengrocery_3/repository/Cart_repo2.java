package com.example.Greengrocery_3.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.Login;
import com.example.Greengrocery_3.Entity.cart;
import com.example.Greengrocery_3.Entity.cart2;
import com.example.Greengrocery_3.Entity.product2;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface Cart_repo2 extends JpaRepository<cart2, Integer> {
    List<cart2> findByCustomerId(Integer customerId);
}