package com.example.Greengrocery_3.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Greengrocery_3.Entity.Order;
import com.example.Greengrocery_3.Entity.cart2;
import com.example.Greengrocery_3.Entity.product3;
import com.example.Greengrocery_3.repository.Cart_repo2;
import com.example.Greengrocery_3.repository.Order_repo;
import com.example.Greengrocery_3.repository.Product_repo2;

import java.time.LocalDate;
import java.util.List;

@Service
public class OrderService {
	@Autowired
    private Cart_repo2 cartRepository;

    @Autowired
    private Order_repo orderRepository;

    @Autowired
    private Product_repo2 productRepository;

    @Transactional
    public Order createOrderFromCart(Integer cartId) {
        Optional<cart2> cartOptional = cartRepository.findById(cartId);
        if (!cartOptional.isPresent()) {
            throw new RuntimeException("Cart not found for ID: " + cartId);
        }

        cart2 cartItem = cartOptional.get();

        double totalAmount = cartItem.getPrice() * cartItem.getQuantity();

        Order order = new Order();
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(totalAmount);
        order.setOrderStatus("preparing");

        // Save the order
        orderRepository.save(order);

        // Update product stock quantities
        Optional<product3> productOptional = productRepository.findById(cartItem.getProductId());
        if (productOptional.isPresent()) {
            product3 product = productOptional.get();
            product.setStockQuantity(product.getStockQuantity() - cartItem.getQuantity());
            productRepository.save(product);
        } else {
            throw new RuntimeException("Product not found for ID: " + cartItem.getProductId());
        }

        // Clear the cart
        cartRepository.delete(cartItem);

        return order;
    }
}

