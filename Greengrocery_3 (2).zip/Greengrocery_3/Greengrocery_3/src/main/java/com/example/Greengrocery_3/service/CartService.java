package com.example.Greengrocery_3.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Greengrocery_3.Entity.Login;
import com.example.Greengrocery_3.Entity.cart;
import com.example.Greengrocery_3.Entity.product2;
import com.example.Greengrocery_3.repository.Cart_repo;
import com.example.Greengrocery_3.repository.Login_repo;
import com.example.Greengrocery_3.repository.Product_repo;

@Service
public class CartService {
	
		@Autowired
	    private Cart_repo cartRepository;
	
	    @Autowired
	    private Product_repo productRepository;
	
	    @Autowired
	    private Login_repo loginRepository;
	    
	 
	    @Transactional
	    public void addItemToCart(Integer productId) {
	    	 Optional<Login> loginOptional = loginRepository.findFirstByOrderByIdAsc();
	         Login customer = loginOptional.orElse(null);

	         product2 product = productRepository.findById(productId).orElseThrow(() -> new RuntimeException("Product not found"));

	         Optional<cart> cartItemOptional;
	         if (customer == null) {
	             cartItemOptional = cartRepository.findByCustomerAndProduct(null, product);
	         } else {
	             cartItemOptional = cartRepository.findByCustomerAndProduct(customer, product);
	         }

	         cart cartItem;
	         if (cartItemOptional.isEmpty()) {
	             cartItem = new cart();
	             cartItem.setCustomer(customer);
	             cartItem.setProduct(product);
	             cartItem.setQuantity(1);
	             cartItem.setPrice(product.getDiscountedPrice());
	         } else {
	             cartItem = cartItemOptional.get();
	             int newQuantity = cartItem.getQuantity() + 1;
	             cartItem.setQuantity(newQuantity);
	             cartItem.setPrice(newQuantity * product.getDiscountedPrice());
	         }

	         cartRepository.save(cartItem);
	     }
    
}
