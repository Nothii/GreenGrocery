package com.example.Greengrocery_3.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.Greengrocery_3.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@RestController
@RequestMapping
public class CartController {
	private static final Logger logger = LoggerFactory.getLogger(CartController.class);
    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public String addToCart(Integer productId) {
    	logger.info("addToCart called with productId: " + productId);
        cartService.addItemToCart(productId);
        return "Item added to cart successfully";
    }
}

