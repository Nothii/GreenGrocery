package com.example.Greengrocery_3.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.Login;
import com.example.Greengrocery_3.Entity.cart;
import com.example.Greengrocery_3.Entity.product2;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface Cart_repo extends JpaRepository<cart, Integer> {
	Optional<cart> findByCustomerAndProduct(Login customer, product2 product);
}