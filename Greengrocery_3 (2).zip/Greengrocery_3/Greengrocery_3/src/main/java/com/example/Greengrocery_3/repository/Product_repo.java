package com.example.Greengrocery_3.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.product2;




public interface Product_repo extends JpaRepository<product2, Integer> {
	
}
