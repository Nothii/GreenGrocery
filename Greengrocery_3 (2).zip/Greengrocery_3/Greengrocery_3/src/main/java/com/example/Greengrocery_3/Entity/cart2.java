package com.example.Greengrocery_3.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Cart")
public class cart2 {
	
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "CartId")
	    private Integer cartId;

	    @Column(name = "CustomerId")
	    private Integer customerId;

	    @Column(name = "ProductId")
	    private Integer productId;

	    @Column(name = "Quantity")
	    private Integer quantity;

	    @Column(name = "Price")
	    private Double price;

	    // Getters and Setters
	    public Integer getCartId() {
	        return cartId;
	    }

	    public void setCartId(Integer cartId) {
	        this.cartId = cartId;
	    }

	    public Integer getCustomerId() {
	        return customerId;
	    }

	    public void setCustomerId(Integer customerId) {
	        this.customerId = customerId;
	    }

	    public Integer getProductId() {
	        return productId;
	    }

	    public void setProductId(Integer productId) {
	        this.productId = productId;
	    }

	    public Integer getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(Integer quantity) {
	        this.quantity = quantity;
	    }

	    public Double getPrice() {
	        return price;
	    }

	    public void setPrice(Double price) {
	        this.price = price;
	    }
	}

	

