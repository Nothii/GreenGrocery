package com.example.Greengrocery_3.repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Greengrocery_3.Entity.Login;



public interface Login_repo extends JpaRepository<Login, Integer> {
	Optional<Login> findFirstByOrderByIdAsc();
}


