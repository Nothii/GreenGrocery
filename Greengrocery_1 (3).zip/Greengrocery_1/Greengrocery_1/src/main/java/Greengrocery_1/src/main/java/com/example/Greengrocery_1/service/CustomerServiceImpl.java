package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer2;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.CustomerRepositorylogin;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;

import java.util.List;

import java.util.Optional;


@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepositorylogin customerRepository;

    @Override
    public Customer2 registerCustomer(Customer2 customer) {
        // Username and Email are unique
        if (customerRepository.findByUsername(customer.getUsername()).isPresent() ||
            customerRepository.findByEmail(customer.getEmail()).isPresent()) {
 
           throw new IllegalArgumentException("Username or Email already exists");
            //phone number eklenebilir
        }
        return customerRepository.save(customer);
    }

    @Override
    public Customer2 loginCustomer(String username, String password) {
        Optional<Customer2> optionalCustomer = customerRepository.findByUsername(username);
        if (optionalCustomer.isPresent()) {
            Customer2 customer = optionalCustomer.get();
            // Check password as plain text (not recommended for production)
            if (password.equals(customer.getPassword())) {
                return customer;
            }
        }
        return null;
    }
}
