package Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer1;

import java.util.Optional;

public interface CustomerRepository1 extends JpaRepository<Customer1, Integer> {
    Optional<Customer1> findByEmail(String email);
}