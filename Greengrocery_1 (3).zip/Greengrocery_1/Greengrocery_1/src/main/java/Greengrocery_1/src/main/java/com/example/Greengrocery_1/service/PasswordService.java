package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer1;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.CustomerRepository1;

import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class PasswordService {

    @Autowired
    private CustomerRepository1 customerRepository;

    @Autowired
    private JavaMailSender mailSender;

    private static final Logger logger = Logger.getLogger(PasswordService.class.getName());

    public void sendPasswordResetEmail(String email) {
        Optional<Customer1> customerOptional = customerRepository.findByEmail(email);
        if (customerOptional.isPresent()) {
            Customer1 customer = customerOptional.get();
            sendEmail(customer.getEmail(), "Your Password", "Your password is: " + customer.getPassword());
        } else {
            logger.info("No customer found with email: " + email);
        }
    }

    private void sendEmail(String to, String subject, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("mycmpe356@outlook.com"); // Use the authenticated email address
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            mailSender.send(message);
            logger.info("Email sent successfully to " + to);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to send email to " + to + ": " + e.getMessage(), e);
        }
    }
}
