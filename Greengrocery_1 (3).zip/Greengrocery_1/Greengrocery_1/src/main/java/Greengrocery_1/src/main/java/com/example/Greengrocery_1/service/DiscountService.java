package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Customer;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.Product;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.CustomerRepository;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.ProductRepository;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class DiscountService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private JavaMailSender mailSender;

    private static final Logger logger = Logger.getLogger(DiscountService.class.getName());

    @Scheduled(cron = "0 0 9 * * ?") // Scheduled date
    public void sendDiscountNotifications() {
        logger.info("Scheduled task started: Checking for discounted products.");

        List<Product> products = productRepository.findAll();
        boolean hasDiscounts = products.stream()
                .anyMatch(product -> product.getDiscountedPrice() < product.getPrice());

        if (hasDiscounts) {
            logger.info("Discounted products found. Sending notifications to customers.");
            List<Customer> customers = customerRepository.findAll();
            for (Customer customer : customers) {
                sendEmail(customer.getEmail(), "We have discounts!",
                        "Dear customer, we have discounts on our products. Visit our store for more details.");
            }
        } else {
            logger.info("No discounted products found.");
        }
    }

    private void sendEmail(String to, String subject, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("mycmpe356@outlook.com"); // Use the authenticated email address
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            mailSender.send(message);
            logger.info("Email sent successfully to " + to);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to send email to " + to + ": " + e.getMessage(), e);
        }
    }
}
