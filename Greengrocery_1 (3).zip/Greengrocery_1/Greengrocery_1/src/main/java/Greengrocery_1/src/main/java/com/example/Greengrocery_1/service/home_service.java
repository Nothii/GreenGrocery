package Greengrocery_1.src.main.java.com.example.Greengrocery_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;

import java.util.List;

@Service
public class home_service {
	
	@Autowired
     private home_repository home;
	
	 public List<home_page> getAllProducts() {
	        return home.findAll();
	    }
}
