package Greengrocery_1.src.main.java.com.example.Greengrocery_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Greengrocery_1.src.main.java.com.example.Greengrocery_1.model.home_page;
import Greengrocery_1.src.main.java.com.example.Greengrocery_1.repository.home_repository;

import java.util.List;

@RestController
@RequestMapping
public class home_controller {
	
	@Autowired
    private home_repository productService;

    @GetMapping("/Products")
    public List<home_page> getAllProducts() {
        return productService.findAll();
    }
}
